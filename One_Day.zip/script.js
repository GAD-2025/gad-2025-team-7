document.addEventListener('DOMContentLoaded', () => {
    const loginFormContainer = document.getElementById('login-form');
    const signupFormContainer = document.getElementById('signup-form');
    const showSignup = document.getElementById('show-signup');
    const showLogin = document.getElementById('show-login');
    const loginForm = loginFormContainer.querySelector('form');

    showSignup.addEventListener('click', (e) => {
        e.preventDefault();
        loginFormContainer.style.display = 'none';
        signupFormContainer.style.display = 'block';
    });

    showLogin.addEventListener('click', (e) => {
        e.preventDefault();
        signupFormContainer.style.display = 'none';
        loginFormContainer.style.display = 'block';
    });

    // 로그인 성공 시 프로필 설정 페이지로 이동 (애니메이션 포함)
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault(); // 폼의 기본 제출 동작을 막음
        
        const overlay = document.getElementById('transition-overlay');
        overlay.classList.add('active');

        // 애니메이션 시간(0.5초) 후 페이지 이동
        setTimeout(() => {
            window.location.href = 'home.html';
        }, 500);
    });
});
