document.addEventListener('DOMContentLoaded', () => {
    // --- STATE MANAGEMENT --- //
    let nav = 0;
    let selectedDate = new Date().toISOString().split('T')[0];
    let events = localStorage.getItem('events') ? JSON.parse(localStorage.getItem('events')) : [];
    let todos = localStorage.getItem('todos') ? JSON.parse(localStorage.getItem('todos')) : [];
    let diaries = localStorage.getItem('diaries') ? JSON.parse(localStorage.getItem('diaries')) : [];

    // --- DOM ELEMENT SELECTORS --- //
    const calendar = document.getElementById('calendar-body');
    const weekdays = ['일', '월', '화', '수', '목', '금', '토'];

    // --- DIARY & CANVAS STATE --- //
    const diaryCanvas = document.getElementById('diary-canvas');
    const diaryTextarea = document.getElementById('diary-textarea');
    const ctx = diaryCanvas.getContext('2d');
    let isDrawing = false;
    let lastX = 0;
    let lastY = 0;
    let penColor = 'black';
    let penSize = 8; // Default to medium size
    let currentTool = 'pen';

    // --- DATA MANIPULATION & SAVING --- //
    function saveData() {
        localStorage.setItem('events', JSON.stringify(events));
        localStorage.setItem('todos', JSON.stringify(todos));
        localStorage.setItem('diaries', JSON.stringify(diaries));
    }
    function deleteEvent(eventId) { events = events.filter(e => e.id !== eventId); saveData(); load(); updateDashboard(selectedDate); }
    function deleteTodo(todoId) { todos = todos.filter(t => t.id !== todoId); saveData(); updateDashboard(selectedDate); }

    // --- UI RENDERING --- //
    function renderSchedule(date) {
        const scheduleList = document.getElementById('schedule-list');
        scheduleList.innerHTML = '';
        const eventsForDay = events.filter(e => e.date === date);
        if (eventsForDay.length === 0) { scheduleList.innerHTML = '<p>등록된 일정이 없습니다.</p>'; } 
        else {
            eventsForDay.forEach(event => {
                const li = document.createElement('li');
                const titleSpan = document.createElement('span');
                titleSpan.innerText = `${event.isImportant ? '[중요] ' : ''}${event.title}`;
                li.appendChild(titleSpan);
                const deleteBtn = document.createElement('button');
                deleteBtn.className = 'delete-item-btn';
                deleteBtn.innerText = '×';
                deleteBtn.addEventListener('click', () => deleteEvent(event.id));
                li.appendChild(deleteBtn);
                scheduleList.appendChild(li);
            });
        }
    }

    function renderTodos(date) {
        const todoList = document.getElementById('todolist-list');
        todoList.innerHTML = '';
        const todosForDay = todos.filter(t => t.date === date);
        if (todosForDay.length === 0) { todoList.innerHTML = '<p>등록된 투두리스트가 없습니다.</p>'; }
        else {
            todosForDay.forEach(todo => {
                const li = document.createElement('li');
                li.classList.toggle('completed', todo.completed);
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.checked = todo.completed;
                checkbox.addEventListener('change', () => { todo.completed = checkbox.checked; li.classList.toggle('completed', todo.completed); saveData(); });
                const label = document.createElement('span');
                label.innerText = todo.title;
                li.appendChild(checkbox); li.appendChild(label);
                const deleteBtn = document.createElement('button');
                deleteBtn.className = 'delete-item-btn';
                deleteBtn.innerText = '×';
                deleteBtn.addEventListener('click', () => deleteTodo(todo.id));
                li.appendChild(deleteBtn);
                todoList.appendChild(li);
            });
        }
    }

    function renderReminders(date) {
        const reminderList = document.getElementById('reminder-list');
        reminderList.innerHTML = '';
        const today = new Date(date);
        const upcomingEvents = events.filter(e => new Date(e.date) >= today).sort((a, b) => new Date(a.date) - new Date(b.date)).slice(0, 6);
        if (upcomingEvents.length === 0) { reminderList.innerHTML = '<p>남은 일정이 없습니다.</p>'; }
        else {
            upcomingEvents.forEach(event => {
                const eventDate = new Date(event.date);
                const diffDays = Math.ceil((eventDate - today) / (1000 * 60 * 60 * 24));
                const card = document.createElement('div');
                card.className = 'reminder-card';
                card.innerHTML = `<div class="d-day">D-${diffDays}</div><div class="event-title">${event.title}</div>`;
                card.style.backgroundColor = `rgba(255, 117, 129, ${Math.max(0.2, 1 - (diffDays / 30))})`;
                reminderList.appendChild(card);
            });
        }
    }

    function renderDiary(date) {
        const diaryEntry = diaries.find(d => d.date === date);
        ctx.clearRect(0, 0, diaryCanvas.width, diaryCanvas.height);
        if (diaryEntry) {
            diaryTextarea.value = diaryEntry.text;
            if (diaryEntry.canvasData) {
                const img = new Image();
                img.onload = () => ctx.drawImage(img, 0, 0);
                img.src = diaryEntry.canvasData;
            }
        } else {
            diaryTextarea.value = '';
        }
    }

    function updateDashboard(date) {
        renderSchedule(date);
        renderTodos(date);
        renderReminders(date);
        renderDiary(date);
    }

    function selectDate(dateString, daySquare) {
        selectedDate = dateString;
        document.querySelectorAll('.date-cell.selected').forEach(cell => cell.classList.remove('selected'));
        if (daySquare) daySquare.classList.add('selected');
        updateDashboard(selectedDate);
    }

    function load() {
        const dt = new Date();
        if (nav !== 0) dt.setMonth(new Date().getMonth() + nav);
        const day = dt.getDate(), month = dt.getMonth(), year = dt.getFullYear();
        const firstDayOfMonth = new Date(year, month, 1);
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const dateString = firstDayOfMonth.toLocaleDateString('ko-kr', { weekday: 'long', year: 'numeric', month: 'numeric', day: 'numeric' });
        const paddingDays = weekdays.indexOf(dateString.split(' ')[3].replace('.', ''));
        document.getElementById('current-month-year').innerText = `${year}년 ${month + 1}월`;
        calendar.innerHTML = '';
        for (let i = 1; i <= paddingDays + daysInMonth; i++) {
            const daySquare = document.createElement('div');
            daySquare.classList.add('date-cell');
            const dayString = `${year}-${String(month + 1).padStart(2, '0')}-${String(i - paddingDays).padStart(2, '0')}`;
            if (i > paddingDays) {
                daySquare.innerHTML = `<div class="date-number">${i - paddingDays}</div>`;
                if (i - paddingDays === day && nav === 0) daySquare.classList.add('today');
                if (dayString === selectedDate) daySquare.classList.add('selected');
                const eventsForDay = events.filter(e => e.date === dayString);
                eventsForDay.forEach(event => {
                    const eventDiv = document.createElement('div');
                    eventDiv.className = `event-preview event-${event.category}`;
                    eventDiv.innerText = event.title;
                    daySquare.appendChild(eventDiv);
                });
                daySquare.addEventListener('click', () => selectDate(dayString, daySquare));
            } else { daySquare.classList.add('other-month'); }
            calendar.appendChild(daySquare);
        }
    }

    // --- CANVAS LOGIC --- //
    function initCanvas() {
        const canvas = diaryCanvas;
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
        ctx.lineJoin = 'round';
        ctx.lineCap = 'round';
        canvas.classList.add('pen-tool'); // Set initial cursor

        const startDrawing = (e) => {
            isDrawing = true;
            [lastX, lastY] = [e.offsetX, e.offsetY];
        };
        const draw = (e) => {
            if (!isDrawing) return;
            ctx.strokeStyle = penColor;
            ctx.globalCompositeOperation = currentTool === 'pen' ? 'source-over' : 'destination-out';
            ctx.lineWidth = currentTool === 'eraser' ? penSize * 2 : penSize; // Eraser is bigger
            ctx.beginPath();
            ctx.moveTo(lastX, lastY);
            ctx.lineTo(e.offsetX, e.offsetY);
            ctx.stroke();
            [lastX, lastY] = [e.offsetX, e.offsetY];
        };
        const stopDrawing = () => isDrawing = false;

        canvas.addEventListener('mousedown', startDrawing);
        canvas.addEventListener('mousemove', draw);
        canvas.addEventListener('mouseup', stopDrawing);
        canvas.addEventListener('mouseout', stopDrawing);
    }

    // --- INITIALIZATION --- //
    function init() {
        initCanvas();
        const addScheduleForm = document.getElementById('add-schedule-form');
        const addTodoForm = document.getElementById('add-todo-form');

        // Month Navigation
        document.getElementById('prev-month').addEventListener('click', () => { nav--; load(); });
        document.getElementById('next-month').addEventListener('click', () => { nav++; load(); });

        // Main Tab Switching
        document.querySelectorAll('.dash-tab-link').forEach(link => {
            link.addEventListener('click', () => {
                const tab = link.getAttribute('data-tab');
                document.querySelectorAll('.dash-tab-link').forEach(l => l.classList.remove('active'));
                link.classList.add('active');
                document.querySelectorAll('.dash-tab-content').forEach(c => c.classList.remove('active'));
                document.getElementById(tab).classList.add('active');
            });
        });

        // Home Tab: Schedule & Todo Forms
        document.getElementById('add-schedule-btn').addEventListener('click', () => addScheduleForm.style.display = addScheduleForm.style.display === 'block' ? 'none' : 'block');
        document.getElementById('add-todo-btn').addEventListener('click', () => addTodoForm.style.display = addTodoForm.style.display === 'block' ? 'none' : 'block');
        document.getElementById('new-schedule-allday').addEventListener('change', (e) => { document.getElementById('new-schedule-time').style.display = e.target.checked ? 'none' : 'block'; });
        document.getElementById('save-schedule-btn').addEventListener('click', () => {
            const title = document.getElementById('new-schedule-title').value;
            if (title) {
                events.push({ id: Date.now(), date: selectedDate, title: title, isImportant: document.getElementById('new-schedule-important').checked, isAllDay: document.getElementById('new-schedule-allday').checked, time: document.getElementById('new-schedule-time').value, category: 'personal' });
                saveData(); load(); updateDashboard(selectedDate); addScheduleForm.style.display = 'none';
            }
        });
        document.querySelectorAll('#home-tab .template-btn[data-category]').forEach(btn => {
            btn.addEventListener('click', () => { events.push({ id: Date.now(), date: selectedDate, title: btn.dataset.title, category: btn.dataset.category }); saveData(); load(); updateDashboard(selectedDate); });
        });
        document.getElementById('new-todo-repeat').addEventListener('change', (e) => { document.getElementById('repeat-end-date-container').style.display = e.target.checked ? 'block' : 'none'; });
        document.getElementById('save-todo-btn').addEventListener('click', () => {
            const title = document.getElementById('new-todo-title').value;
            if (!title) return;
            const isRepeat = document.getElementById('new-todo-repeat').checked;
            if (isRepeat) {
                const endDate = new Date(document.getElementById('new-todo-end-date').value);
                let currentDate = new Date(selectedDate);
                while (currentDate <= endDate) {
                    todos.push({ id: Date.now() + Math.random(), date: currentDate.toISOString().split('T')[0], title: title, completed: false });
                    currentDate.setDate(currentDate.getDate() + 7);
                }
            } else { todos.push({ id: Date.now(), date: selectedDate, title: title, completed: false }); }
            saveData(); updateDashboard(selectedDate); addTodoForm.style.display = 'none';
        });

        // Records Tab: Diary Toolbar & Saving
        document.querySelectorAll('.tool-btn[data-tool]').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelector('.tool-btn.active')?.classList.remove('active');
                btn.classList.add('active');
                currentTool = btn.dataset.tool;
                diaryCanvas.classList.remove('pen-tool', 'eraser-tool');
                if (currentTool === 'pen') diaryCanvas.classList.add('pen-tool');
                else if (currentTool === 'eraser') diaryCanvas.classList.add('eraser-tool');
            });
        });
        document.querySelectorAll('.color-box').forEach(box => {
            box.addEventListener('click', () => {
                document.querySelector('.color-box.active')?.classList.remove('active');
                box.classList.add('active');
                penColor = box.dataset.color;
            });
        });
        document.querySelectorAll('.size-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelector('.size-btn.active')?.classList.remove('active');
                btn.classList.add('active');
                penSize = parseInt(btn.dataset.size, 10);
            });
        });
        document.getElementById('image-upload-input').addEventListener('change', (e) => {
            const reader = new FileReader();
            reader.onload = (event) => { const img = new Image(); img.onload = () => ctx.drawImage(img, 0, 0, diaryCanvas.width, diaryCanvas.height); img.src = event.target.result; };
            reader.readAsDataURL(e.target.files[0]);
        });
        document.querySelectorAll('.emoji-picker span').forEach(emoji => { emoji.addEventListener('click', () => { diaryTextarea.value += emoji.innerText; }); });
        document.getElementById('save-diary-btn').addEventListener('click', () => {
            const diaryEntry = diaries.find(d => d.date === selectedDate);
            const canvasData = diaryCanvas.toDataURL();
            const textData = diaryTextarea.value;
            if (diaryEntry) {
                diaryEntry.text = textData;
                diaryEntry.canvasData = canvasData;
            } else {
                diaries.push({ date: selectedDate, text: textData, canvasData: canvasData, id: Date.now() });
            }
            saveData();
            alert('다이어리가 저장되었습니다.');
        });

        // Collection View
        const sidebar = document.getElementById('collection-sidebar');
        document.getElementById('collection-trigger').addEventListener('click', () => { sidebar.classList.toggle('open'); });
        document.getElementById('collection-diary-btn').addEventListener('click', () => {
            const content = document.getElementById('collection-content');
            content.innerHTML = '';
            diaries.forEach(diary => {
                const item = document.createElement('div');
                item.className = 'collection-item';
                item.innerHTML = `<div class="date">${diary.date}</div><p class="text">${diary.text.substring(0, 100)}...</p>${diary.canvasData ? `<img src="${diary.canvasData}">` : ''}`;
                content.appendChild(item);
            });
        });

        // Initial Load
        load();
        updateDashboard(selectedDate);
    }

    init();
});